import javax.swing.*;
public class ParkingApp{

   public static void main(String[] args) {
   
      Parking p = new Parking ();
      p.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   }
}